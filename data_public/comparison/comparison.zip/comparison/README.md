# So Long Sucker - Comparison Data

Game data from LLM players in "So Long Sucker" - a negotiation/betrayal board game.

## Research Question

Do LLMs **strategically deceive** (LYING) or just **produce plausible noise** (BULLSHITTING)?

## Data Structure

```
comparison/
├── 3chip/
│   ├── silent.json     # 43 games, no chat
│   └── talking.json    # 43 games, with chat
├── 5chip/
│   ├── silent.json     # 20 games, no chat (merged from 2 sessions)
│   └── talking.json    # 20 games, with chat (merged from 2 sessions)
├── 7chip/
│   ├── silent.json     # 10 games, no chat
│   └── talking.json    # 10 games, with chat
└── README.md
```

## Game Summary

| Chips | Silent Games | Talking Games | Total |
|-------|-------------|---------------|-------|
| 3     | 43          | 43            | 86    |
| 5     | 20          | 20            | 40    |
| 7     | 10          | 10            | 20    |
| **Total** | **73**  | **73**        | **146** |

## Player Models

All games use the same 4 LLM players:

| Color  | Model                           |
|--------|--------------------------------|
| red    | gemini-3-flash-preview          |
| blue   | moonshotai/kimi-k2-instruct-0905 |
| green  | qwen/qwen3-32b                  |
| yellow | openai/gpt-oss-120b             |

## File Format

Each JSON file contains:
```json
{
  "session": {
    "id": "...",
    "provider": "mixed",
    "playerModels": { "red": "...", "blue": "...", ... },
    "chips": 3|5|7,
    "silent": true|false,
    "totalGames": N,
    "completedGames": N,
    "mergedFrom": ["session-id-1", "session-id-2"]  // if merged
  },
  "snapshots": [
    // Array of game state snapshots
    // Each snapshot includes: gameId, turn, phase, state, etc.
    // Talking mode includes: chatHistory, llmRequest
  ]
}
```

## Known Issues

- **Talking mode bloat**: Chat history is duplicated in every snapshot (~4x larger than necessary). Data is valid but redundant.

## Data Collection Date

January 10-11, 2026
